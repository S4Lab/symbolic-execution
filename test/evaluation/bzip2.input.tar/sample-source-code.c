#include <stdio.h>

int main () {
  printf ("This is a sample code\n");
  return 0;
}

